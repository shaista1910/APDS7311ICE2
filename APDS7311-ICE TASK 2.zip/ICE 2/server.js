
//sets up an HTTPS server using Node.js, Express, and the https module.
//Import required modules
const fs = require('fs')
const https = require('https')
const app = require('./index')
const port = 8000

//Configure SSL/TLS options
//specifying the SSL/TLS certificate and private key that the HTTPS server will use for secure communication. These options are required for creating an HTTPS server. 
//You are reading these files using the fs.readFileSync method
const options = 
{
    key: fs.readFileSync('./Keys/privatekey.pem'),
    cert: fs.readFileSync('./Keys/certificate.pem')
}
//Create the HTTPS server
//options: An object containing SSL/TLS configuration options (private key and certificate).
//app: This is your Express application, which will handle incoming HTTP requests.
const server = https.createServer(options, app)

//Start the server and listen on the specified port
//starts the HTTPS server and listens on the specified port (8000 in this case). 
//When the server successfully starts, it logs a message indicating that the server is running on the specified port.
server.listen(port, () =>{
    console.log('server started on port' + port)
});