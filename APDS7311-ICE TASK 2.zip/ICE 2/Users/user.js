//defines a Mongoose schema for a User model and exports it as a Mongoose model
//Import the mongoose library
const mongoose = require('mongoose')

//Define User Schema
//a Mongoose schema is created for the User model. This schema defines the structure and data types for user 
//documents that will be stored in the MongoDB collection associated with this model.
const userSchema = mongoose.Schema({
    name: {type: String, required: true},
    surname: {type: String, required: true},
    username: {type: String, required: true},
    password: {type: String, required: true},
    email: {type: String, required: true}
})

// exports the User model, making it available for use in other parts of your application. The mongoose.model function creates a Mongoose model for the "users" collection in the MongoDB database, using the userSchema definition. 
//The first argument ('users') specifies the name of the collection in the database where these documents will be stored, and the second argument (userSchema) specifies the schema that defines the document structure.
module.exports = mongoose.model('users', userSchema)

