//Import required libraries and modules
const express = require('express') // Imports the Express framework.
const app = express() // Creates an Express application.
const mongoose = require('mongoose') // Imports the Mongoose library for MongoDB interactions.
const User = require('./Users/user') // Imports the User model (presumably defined in a separate file).
const bcrypt = require('bcrypt') // Imports the bcrypt library for password hashing.

//Define the MongoDB connection string
const connstring = 'mongodb+srv://st10090003:5QUESlXqixf4NTud@cluster0.oeiqjcs.mongodb.net/'

//Establish a connection to the MongoDB database
mongoose.connect(connstring, {useNewUrlParser: true, useUnifiedTopology:true})
.then(() =>{
    console.log('Connection established successfully')
})
.catch(() => {
    console.log('Connection failed')
})

//Configure Express to parse JSON data - Middleware - tells Express to parse incoming JSON data, 
//which is commonly used for sending data in the request body.
app.use(express.json())

//Set up a bcrypt salt round parameter -The saltRounds variable specifies the number of rounds used by bcrypt to hash passwords. 
//Increasing the number of rounds increases the security of the hash but also increases the time it takes to compute the hash.
const saltRounds = 10
//Create a POST route for user registration - This route handles HTTP POST requests to the /register endpoint. 
//It expects the client to send user registration data in the request body.
// Code for hashing the password, creating a User object, 
//and saving it to the database.
app.post('/register', (req, res) =>{
    bcrypt.hash(req.body.password, saltRounds)
    .then(hash => {
        const user = new User({
            name: req.body.name,
            surname: req.body.surname,
            username: req.body.username,
            password: hash,
            email: req.body.email
        })
        user.save()
        .then(result =>{ //Then,if it managed to save
            res.status(201).json({message: 'user saved sucessfully', result: result })
        })
        .catch(error =>{
            res.status(500).json({error: 'failed to save user!'})
        })
    })
    .catch(err => {
        console.log(err)
        res.status(500).json({error: 'hashing failed'})
    })
})

//Export the Express app -  exports the app so that it can be used in other parts of your application
module.exports = app;